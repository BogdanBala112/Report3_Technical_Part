import cv2
import numpy as np
import os
import sys
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay, ConvexHull
from skimage import measure
import pandas as pd
from scipy.interpolate import make_interp_spline

def compute_centroid(contour):
    return np.mean(contour, axis=0)  # Returns (y, x)

# Function to merge contours only if their centroids are aligned on Y and are close
def merge_contours_by_alignment(contours, y_threshold, x_tolerance):
    merged_contours = []
    used = set()

    for i, c1 in enumerate(contours):
        if i in used:
            continue
        c1_centroid = compute_centroid(c1)
        # print("c1_centroid " , c1_centroid)
        y_min1, y_max1 = np.min(c1[:, 0]), np.max(c1[:, 0])
        merged_contour = c1.copy()

        for j, c2 in enumerate(contours):
            if i != j and j not in used:
                c2_centroid = compute_centroid(c2)
                # print("c2_centroid " , c2_centroid)
                y_min2, y_max2 = np.min(c2[:, 0]), np.max(c2[:, 0])
                # print("y_min2 = %d, y_max2 = %d", y_min2, y_max2)
                # Check if centroids are aligned on Y-axis (similar X values)
                if abs(c1_centroid[1] - c2_centroid[1]) <= x_tolerance:
                    # Check if contours are close in Y distance
                    if abs(y_min1 - y_max2) < y_threshold or abs(y_max1 - y_min2) < y_threshold:
                        merged_contour = np.vstack([merged_contour, c2])
                        used.add(j)
        cv2.waitKey(0)
        merged_contours.append(merged_contour)
        used.add(i)

    return merged_contours


def get_convex_contour(contour):
    if len(contour) < 3:
        return contour  # A convex hull needs at least 3 points

    hull = ConvexHull(contour)  # Compute convex hull
    convex_contour = contour[hull.vertices]  # Extract convex hull points
    convex_contour = np.vstack([convex_contour, convex_contour[0]])
    return convex_contour


def process_images(image_folder):
  
    diff_folder = os.path.join(image_folder, "diff_images")
    os.makedirs(diff_folder, exist_ok=True)

    # Get all image filenames in the folder
    image_files = [f for f in os.listdir(image_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.bmp'))]
    def extract_key(filename):
        # Extract the last 5 characters, convert to int for sorting
        return int(filename[-9:-4])  # Adjust slicing if needed
    
    image_files = sorted(image_files, key=extract_key) 
    # print(image_files)   
    data = []
    previous_image = None
    for index, filename in enumerate(image_files):
        image_path = os.path.join(image_folder, filename)

        # Read the image
        image = cv2.imread(image_path)
        if image is None:
            print(f"Error: Unable to load image {filename}")
            continue

        # Calculate the difference between consecutive images and save
        if previous_image is not None:
            diff = cv2.absdiff(previous_image, image)
            if len(diff.shape) == 3:  # Check if the image has multiple channels (i.e., color)
                diff_gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            else:
                diff_gray = diff  # Already grayscale
            
            # clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            # Apply CLAHE
            # norm_image = clahe.apply(diff_gray)
            norm_diff = cv2.normalize(diff_gray, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            gauss_diff = cv2.GaussianBlur(norm_diff, (7, 9), sigmaX=2)
            # -------------- bilateral filtering not used ---------------------
            # filtered_image = cv2.bilateralFilter(image, d=9, sigmaColor=75, sigmaSpace=75)

#  --------------------- working area ------------------------------------
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 7))
            # Apply dilation
            dilated_grayscale = cv2.dilate(gauss_diff, kernel, iterations=1)
            normalized_image = cv2.normalize(dilated_grayscale, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
            image_data = np.array(normalized_image)
            x = np.linspace(0, image_data.shape[1], image_data.shape[1])
            y = np.linspace(0, image_data.shape[0], image_data.shape[0])
            x, y = np.meshgrid(x, y)
            z = image_data
            z_intersect = 45  # De exemplu, un plan la valoarea 128 de gri
 
            # Găsirea punctelor de intersecție
            contours = measure.find_contours(z, z_intersect)
            filtered_contours = []
            min_area = 150
            min_x_extent = 30

            # Calcularea ariei regiunilor de intersecție
            areas = []
            for contour in contours:
                x_contour = contour[:, 1]
                y_contour = contour[:, 0]
                # Folosim formula poligonului pentru a calcula aria
                n = len(x_contour)
                area = 0.0
                for i in range(n):
                    j = (i + 1) % n
                    area += x_contour[i] * y_contour[j]
                    area -= y_contour[i] * x_contour[j]
                area = abs(area) / 2.0
                x_min = x_contour.min()
                x_max = x_contour.max()
                x_extent = x_max - x_min  # Width along the x-axis
                # areas.append(area)
                if area >= min_area and x_extent <= min_x_extent:
                    filtered_contours.append(contour)
                    areas.append(area)

            y_distance_threshold = 20
            x_tolerance = 10
            # Apply merging based on Y-alignment and proximity
            merged_contours = merge_contours_by_alignment(filtered_contours, y_distance_threshold, x_tolerance)

            convex_contours = [get_convex_contour(contour) for contour in merged_contours]
            filtered_contours  = convex_contours
            # -------------  Afișarea ariilor calculate--------------------
            # # for i, area in enumerate(areas):
            # #     print(f'Aria conturului {i + 1}: {area:.2f}')
            
            # # Vizualizarea graficului 3D și a planului de intersecție
            # fig = plt.figure()
            # ax = fig.add_subplot(111, projection='3d')
            # ax.plot_surface(x, y, z, cmap='gray', alpha=0.5)
            
            # # Adăugarea contururilor pe grafic
            # for contour in filtered_contours:
            #     x_contour = contour[:, 1]
            #     y_contour = contour[:, 0]
            #     z_contour = np.full_like(x_contour, z_intersect)
            #     ax.plot(x_contour, y_contour, z_contour, color='red')
            
            # # Personalizare grafic
            # ax.set_title('Grafic 3D din Imagine PNG cu Plan de Intersecție')
            # ax.set_xlabel('X axis')
            # ax.set_ylabel('Y axis')
            # ax.set_zlabel('Grayscale Value')
            
            # plt.show()
            # ---------   end afisare ---------------------------------------
#  -------------------------------------------------------
            diff_filename = f"diff_{filename}"
            diff_path = os.path.join(diff_folder, diff_filename)
            cv2.imwrite(diff_path, dilated_grayscale)
            image_array = np.array(dilated_grayscale)
            data.append({"Index": index, "Filename": filename, "Image_Array": image_array, "contours":filtered_contours} )

        previous_image = image
    df = pd.DataFrame(data)


    return df

def compute_contour_stats(df):
    """
    Computes a dictionary where:
    - Key: Index from the DataFrame
    - Value: [total surface area of all contours, number of contours]
    
    :param df: Pandas DataFrame containing 'Index' and 'contours' columns.
    :return: Dictionary {Index: [total_surface, num_contours]}
    """
    contour_stats = {}

    for _, row in df.iterrows():
        index = row["Index"]
        contours = row["contours"]

        # Compute total area of all contours
        total_surface = sum(cv2.contourArea(contour.astype(np.float32)) for contour in contours) if contours else 0
        num_contours = len(contours)  # Number of contours

        # Store in dictionary as a list [total_surface, num_contours]
        contour_stats[index] = [total_surface, num_contours, total_surface / num_contours if num_contours > 0 else 0]

    return contour_stats


def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <folder_path>")
        sys.exit(1)

    image_folder = sys.argv[1]
    if not os.path.isdir(image_folder):
        print(f"Error: {image_folder} is not a valid directory.")
        sys.exit(1)
    
    df = process_images(image_folder)

    print(df.head())

    contour_statistics = compute_contour_stats(df)

    indices = np.array(list(contour_statistics.keys()))
    num_contours = np.array([contour_statistics[idx][1] for idx in indices])

    quartic_coeffs = np.polyfit(indices, num_contours, 4)  # Quartic polynomial fit
    quartic_poly = np.poly1d(quartic_coeffs)  # Create polynomial function  
    x_smooth = np.linspace(min(indices), max(indices), 300)
    y_quartic_smooth = quartic_poly(x_smooth)  # Quartic polynomial values
    plt.figure(figsize=(8, 5))
    plt.scatter(indices, num_contours, color='red', label="Original Data (Samples)", zorder=3)

    # Plot the quartic polynomial fit
    plt.plot(x_smooth, y_quartic_smooth, color='green', linestyle='solid', label="Quartic Fit (Order 4)", zorder=1)

    # Labels and title
    plt.xlabel("X")
    plt.ylabel("Y (Approximated Values)")
    plt.title("Polynomial Approximation (Cubic vs. Quartic)")
    plt.legend()
    plt.grid(True)

    # Show the plot
    plt.show()

    # Generate smooth curve using spline interpolation
    x_smooth = np.linspace(min(indices), max(indices), 300)  # Smooth x values
    spline = make_interp_spline(indices, num_contours, k=1)  # Cubic spline interpolation
    y_smooth = spline(x_smooth)

    # Plot the original data points
    plt.figure(figsize=(8, 5))
    plt.scatter(indices, num_contours, color='red', label="Original Data (Samples)", zorder=3)
    plt.plot(x_smooth, y_smooth, color='blue', label="Spline Interpolation", zorder=2)

    # Labels and title
    plt.xlabel("Index")
    plt.ylabel("Number of Contours")
    plt.title("Number of Contours vs. Index (With Spline Interpolation)")
    plt.legend()
    plt.grid(True)

    # Show the plot
    plt.show()


    
    indices = np.array(list(contour_statistics.keys()))
    num_contours = np.array([contour_statistics[idx][0] for idx in indices])
    # Generate smooth curve using spline interpolation
    x_smooth = np.linspace(min(indices), max(indices), 300)  # Smooth x values
    spline = make_interp_spline(indices, num_contours, k=1)  # Cubic spline interpolation
    y_smooth = spline(x_smooth)

    # Plot the original data points
    plt.figure(figsize=(8, 5))
    plt.scatter(indices, num_contours, color='red', label="Original Data (Samples)", zorder=3)
    plt.plot(x_smooth, y_smooth, color='green', label="Spline Interpolation", zorder=2)

    # Labels and title
    plt.xlabel("Index")
    plt.ylabel("Number of Contours")
    plt.title("Number of Contours vs. Index (With Spline Interpolation)")
    plt.legend()
    plt.grid(True)

    # Show the plot
    plt.show()

    indices = np.array(list(contour_statistics.keys()))
    num_contours = np.array([contour_statistics[idx][2] for idx in indices])

    # Generate smooth curve using spline interpolation
    x_smooth = np.linspace(min(indices), max(indices), 300)  # Smooth x values
    spline = make_interp_spline(indices, num_contours, k=1)  # Cubic spline interpolation
    y_smooth = spline(x_smooth)

    # Plot the original data points
    plt.figure(figsize=(8, 5))
    plt.scatter(indices, num_contours, color='red', label="Original Data (Samples)", zorder=3)
    plt.plot(x_smooth, y_smooth, color='yellow', label="Spline Interpolation", zorder=2)

    # Labels and title
    plt.xlabel("Index")
    plt.ylabel("Number of Contours")
    plt.title("Number of Contours vs. Index (With Spline Interpolation)")
    plt.legend()
    plt.grid(True)

    # Show the plot
    plt.show()
    # Print results
    print(contour_statistics)

if __name__ == "__main__":
    main()


# ------------------------------ to do ----------------------------
#   - on the data frame, eliminate images that have contours with more than 60 percent different then the next and previous frame 
# are different 
#   - remove concave parts
#   - unify contours that are close to each other on y axis
